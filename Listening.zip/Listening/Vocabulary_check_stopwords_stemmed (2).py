import re, math
from collections import Counter

WORD = re.compile(r'\w+')

def cosine(vec1, vec2):
     intersection = set(vec1.keys()) & set(vec2.keys())
     numerator = sum([vec1[x] * vec2[x] for x in intersection])

     sum1 = sum([vec1[x]**2 for x in vec1.keys()])
     sum2 = sum([vec2[x]**2 for x in vec2.keys()])
     denominator = math.sqrt(sum1) * math.sqrt(sum2)

     if not denominator:
        return 0.0
     else:
        return float(numerator) / denominator

def text_to_vector(text):
     words = WORD.findall(text)
     return Counter(words)


from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
stoplist = stopwords.words('english')



file1= open('text1.txt') # Reference essay which we will have in the dataset
file2= open('text2.txt') # essay written by the candidate

# Reading the both the files
text1 = file1.read()
text2 = file2.read()
ps = PorterStemmer()
# Removing the stop words and changing all the words to their roots words    
clean = [ps.stem(word) for word in text1.split() if word not in stoplist]
clean1 = [ps.stem(word) for word in text2.split() if word not in stoplist]
clean=' '.join(clean)
clean1=' '.join(clean1)

#Making dicitonary of both the files
vector1 = text_to_vector(clean)
vector2 = text_to_vector(clean1)
# applying cosine similarity formula
cosine = cosine(vector1,vector2)
    

print ('Cosine:', cosine)
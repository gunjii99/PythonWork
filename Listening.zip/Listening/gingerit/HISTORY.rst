.. :changelog:

History
-------

0.6 (2015-10-20)
---------------------

* Update to new secure api url


0.5.5 (2015-01-11)
---------------------

* Updates requirements and python package

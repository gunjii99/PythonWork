============
Installation
============

At the command line::

    $ easy_install gingerit

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv gingerit
    $ pip install gingerit

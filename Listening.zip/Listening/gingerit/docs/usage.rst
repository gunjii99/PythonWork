========
Usage
========

To use Gingerit in a project::

    import gingerit
